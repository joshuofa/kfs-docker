TOMCAT7_USER=kualiadm
export TOMCAT7_USER

TOMCAT7_GROUP=kuali
export TOMCAT7_GROUP

CATALINA_OPTS="-Dserver.name=http://localhost:8080"
export CATALINA_OPTS

CATALINA_PID="/transactional/catalina.pid"
export CATALINA_PID

CATALINA_OUT=/logs/catalina.out
export CATALINA_OUT

JAVA_HOME=/opt/jdk1.8.0_45
export JAVA_HOME

JAVA_OPTS="-Xmx1g -Xms512m -XX:NewSize=128m -XX:MaxNewSize=256m -XX:+UseParNewGC -XX:+UseConcMarkSweepGC -XX:SurvivorRatio=128 -XX:MaxTenuringThreshold=0 -XX:+UseTLAB -XX:+CMSClassUnloadingEnabled -Dadditional.kfs.config.locations=/configuration/kfs-config/uaf-kfs-config.properties,/configuration/kfs-config/uaf-rice-config.properties,/security/uaf-security-config.properties -Djava.awt.headless=true -Dorg.apache.jasper.compiler.Parser.STRICT_QUOTE_ESCAPING=false -Dorg.terracotta.quartz.skipUpdateCheck=true"
export JAVA_OPTS
